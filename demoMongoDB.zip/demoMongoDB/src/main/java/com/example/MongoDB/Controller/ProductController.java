package com.example.MongoDB.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.MongoDB.Model.Product;
import com.example.MongoDB.services.ProductService;

@RestController
@RequestMapping(value="/rest")
public class ProductController {
	
	private final ProductService productService;
	 
    @Autowired
    ProductController(ProductService service) {
        this.productService = service;
    };
	
	@RequestMapping(value="/display", method = RequestMethod.GET)
    List<Product> findAll() {
        return productService.findAll();
    }
}
