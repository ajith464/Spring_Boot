package com.example.MongoDB.demoMongoDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@RestController
@SpringBootApplication
public class DemoMongoDbApplication {
	
	/*private ProductMongoRepository mongoRepository;
	@Autowired
	DemoMongoDbApplication(ProductMongoRepository repository) {
        this.mongoRepository = repository;
    }*/
	
	public static void main(String[] args) {
		SpringApplication.run(DemoMongoDbApplication.class, args);
	}
	
	/*@RequestMapping(value="/rest/display",method=RequestMethod.GET)
	public List<Product> display(){
		return mongoRepository.findAll() ; 
	}
	
	@RequestMapping(value="/rest/findOne",method=RequestMethod.GET)
	public Product findById(){
		return mongoRepository.findOne("596e22ef7decd887c37f5ca3"); 
	}
	
	@RequestMapping(value="/rest/totalRec",method=RequestMethod.GET)
	public long totalRecords(){
		return mongoRepository.count(); 
	}*/
	
	/*@RequestMapping(value="/rest/delete", method=RequestMethod.DELETE)
	public List<Product> deleteById(){
		productMongoRepository.deleteById("103");
		return productMongoRepository.findAll() ; 
	}*/
}
