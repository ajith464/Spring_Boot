package com.example.MongoDB.demoMongoDB;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.MongoDB.Model.Product;

public interface ProductMongoRepository extends MongoRepository<Product, String>{
	//List<Product> deleteById(String prdId);
	//List<Product> findAll();
	//List<Product> findByName(String prdName);
	
}
