package com.example.MongoDB.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.MongoDB.Model.Product;
import com.example.MongoDB.demoMongoDB.ProductMongoRepository;
import com.example.MongoDB.services.ProductService;

public class ProductServiceImpl implements ProductService {

	private final ProductMongoRepository mongoRepository;
	
	@Autowired
	ProductServiceImpl(ProductMongoRepository repository) {
        this.mongoRepository = repository;
    }
	
	@Override
	public List<Product> findAll() {
		
		List<Product> productList = mongoRepository.findAll();
        return productList;
	}
}
