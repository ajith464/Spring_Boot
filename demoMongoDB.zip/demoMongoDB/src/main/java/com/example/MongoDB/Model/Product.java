package com.example.MongoDB.Model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "product")
public class Product {

		@Id
		private String prdId;
		private String prdName;
		private String prdPrice;
			
		public Product(){
			
		}
		
		public Product(String prdId, String prdName, String prdPrice){
			this.prdId = prdId;
			this.prdName = prdName;
			this.prdPrice = prdPrice;
		}
		
		public String getPrdId() {
			return prdId;
		}
		public void setPrdId(String prdId) {
			this.prdId = prdId;
		}
		
		public String getPrdName() {
			return prdName;
		}

		public void setPrdName(String prdName) {
			this.prdName = prdName;
		}

		public String getPrdPrice() {
			return prdPrice;
		}
		public void setPrdPrice(String prdPrice) {
			this.prdPrice = prdPrice;
		}
}
