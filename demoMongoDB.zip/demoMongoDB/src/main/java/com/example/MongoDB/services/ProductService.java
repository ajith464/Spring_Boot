package com.example.MongoDB.services;

import java.util.List;

import com.example.MongoDB.Model.Product;

public interface ProductService {
	List<Product> findAll();
}
