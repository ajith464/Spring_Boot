package com.example.springBoot.Model;

public class Employee {

	
		private String employeeName;
		private String employeeId;
		private String employeeSalary;
		private String employeeDepartment;
		
		
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public String getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(String employeeId) {
			this.employeeId = employeeId;
		}
		public String getEmployeeSalary() {
			return employeeSalary;
		}
		public void setEmployeeSalary(String employeeSalary) {
			this.employeeSalary = employeeSalary;
		}
		public String getEmployeeDepartment() {
			return employeeDepartment;
		}
		public void setEmployeeDepartment(String employeeDepartment) {
			this.employeeDepartment = employeeDepartment;
		}
}
