package com.example.springBoot.Controller;

import java.util.HashMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springBoot.Model.Employee;

@RestController
@RequestMapping(value="/rest")
public class EmployeeController {
	
	HashMap<String,Employee> empMap = new HashMap<String,Employee>();
	
	EmployeeController(){
		
		Employee emp;
		
		emp = new Employee();
		emp.setEmployeeId("123");
		emp.setEmployeeName("Ajith");
		emp.setEmployeeDepartment("Sales");
		emp.setEmployeeSalary("150000");
		empMap.put(emp.getEmployeeId(), emp);
		
		emp = new Employee();
		emp.setEmployeeId("124");
		emp.setEmployeeName("Shaju");
		emp.setEmployeeDepartment("Sales");
		emp.setEmployeeSalary("162300");
		empMap.put(emp.getEmployeeId(), emp);
		
		emp = new Employee();
		emp.setEmployeeId("125");
		emp.setEmployeeName("Sudarsan");
		emp.setEmployeeDepartment("Marketing");
		emp.setEmployeeSalary("125000");
		empMap.put(emp.getEmployeeId(), emp);
	}
	@RequestMapping(value="/ListEmployee",method = RequestMethod.GET)
    public HashMap<String,Employee> displayEmployee(){
        return empMap;
    }
	
	@RequestMapping(value="/addEmployee",method = RequestMethod.POST)
    public HashMap<String,Employee> addEmployee(@RequestParam(value="name") String empName, 
    						@RequestParam(value="id") 	String empId,
    						@RequestParam(value="department") String empDept,
    						@RequestParam(value="salary") String empSalary){
		
		Employee emp = new Employee();
		emp.setEmployeeId(empId);
		emp.setEmployeeName(empName);
		emp.setEmployeeDepartment(empDept);
		emp.setEmployeeSalary(empSalary);
		empMap.put(emp.getEmployeeId(), emp);
        return empMap;
    }
	
	
	@RequestMapping(value="/updateEmployee",method = RequestMethod.POST)
    public HashMap<String,Employee> updateStudent(@RequestParam(value="name") String empName, 
			@RequestParam(value="id") 	String empId,
			@RequestParam(value="department") String empDept,
			@RequestParam(value="salary") String empSalary) throws Exception {

		
		Employee emp = new Employee();
		emp.setEmployeeId(empId);
		emp.setEmployeeName(empName);
		emp.setEmployeeDepartment(empDept);
		emp.setEmployeeSalary(empSalary);
        if(empMap.containsKey(new Long(emp.getEmployeeId()))){
            empMap.put(emp.getEmployeeId(),emp);
        }else{
            throw new Exception("Employee not found....!");
        }

        return empMap;
    }
	
	
	
	
}
